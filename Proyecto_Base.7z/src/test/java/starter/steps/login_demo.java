package starter.steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class login_demo extends PaginaBase{
	WebDriver driver;
	WebDriverWait wait;	
	private String URLBase ="https://phptravels.org/clientarea.php";
	
	public login_demo(WebDriver driver) {
		super(driver);
		this.driver = driver;
		System.out.println("Inicializando elementos...");

		PageFactory.initElements(new AjaxElementLocatorFactory(this.driver, TIMEOUT), this);
		this.driver.get(URLBase);
		
		}
	
	
	

	@FindBy(id="inputEmail")
	private WebElement TXT_user;
	
	@FindBy(id="inputPassword")
	private WebElement TXT_pass;
	
	@FindBy(id="main_moduleHeader_control")
	private WebElement Logo;
	
	@FindBy(id="login")
	private WebElement BTN_login;
	
	@FindBy(xpath="//*[@id=\"recaptcha-anchor\"]/div[1]")
	private WebElement captcha; 
	
	
	
	//@Step("#actor ingresa con el usuario {0} y la contraseña {1}")
	public void loguearse(String Usuario, String Contraseña) {
		
		//user_box = driver.findElement(By.id("login_loginForm_user"));
		//user_box.sendKeys("fbarrionuevo");
		//pass_box.sendKeys("fbarrionuevo");
		System.out.println("Esperando por la caja de texto usuario...");
		
		//wait.until(ExpectedConditions.elementToBeClickable(TXT_user) );
		
		TXT_user.sendKeys(Usuario);
		TXT_pass.sendKeys(Contraseña);
		captcha.click();
		BTN_login.click();
		
		//wait.until(ExpectedConditions.elementToBeClickable(Logo) );
		//System.out.print(driver.getCurrentUrl());
	}

	public String getCurrentUrl() {
		// TODO Auto-generated method stub
		return driver.getCurrentUrl();
	}
	
	
	
}
