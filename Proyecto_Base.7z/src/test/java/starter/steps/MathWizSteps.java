package starter.steps;

import static org.junit.Assert.assertTrue;

import net.thucydides.core.annotations.Step;

public class MathWizSteps {

    String actor;
    int valor;

    @Step("#actor starts with {0}")
    public void startsWith(int amount) {
    	valor = amount;
    }

    @Step("#actor adds {0}")
    public void adds(int amount) {
    	valor += amount;
    }

    @Step("#actor should have {0}")
    public boolean shouldHave(int expectedTotal) {
        return(valor == expectedTotal);
    }
}
