package starter.steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.thucydides.core.annotations.Step;



public class login extends PaginaBase{
	//WebDriver driver =null;
	WebDriverWait wait;	
	private String URLBase = "http://canalesdigitales.expand/frontEnd/login";
	
	public login(WebDriver pdriver) {
		super(pdriver);
		//driver = pdriver;
		
		System.out.println("Inicializando elementos...");
		PageFactory.initElements(driver, this);
		driver.get(URLBase);
	}
	
	@FindBy(id="login_loginForm_user")
	protected WebElement TXT_user;
	
	@FindBy(id="login_loginForm_password")
	protected WebElement TXT_pass;
	
	@FindBy(id="main_moduleHeader_control")
	protected WebElement Logo;
	
	@FindBy(id="login_loginForm_enterButton_button")
	protected WebElement BTN_login;
	
	
	
	@Step("#actor ingresa con el usuario {0} y la contraseña {1}")
	public void loguearse(String Usuario, String Contraseña) {
		TXT_user.sendKeys(Usuario);
		TXT_pass.sendKeys(Contraseña);

		BTN_login.click();
		
	}

	public String getCurrentUrl() {
		// TODO Auto-generated method stub
		return driver.getCurrentUrl();
	}
	
	
	
}
