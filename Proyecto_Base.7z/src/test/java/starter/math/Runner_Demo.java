package starter.math;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Narrative;
import net.thucydides.core.annotations.Title;
import net.thucydides.core.annotations.WithTag;
import net.thucydides.core.annotations.WithTags;

import static org.junit.Assert.assertTrue;

//import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;

import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import starter.steps.Navegador;
import starter.steps.login_demo;

@RunWith(SerenityRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@Narrative(text={"Prueba de automation."})
public class Runner_Demo {
	//@Managed
		static WebDriver driver;
		public login_demo login = null;
		//private HomePagina Home = null;
		
		@Before
		public void setUp(){
			Navegador driverAusar = new Navegador();
			driver = driverAusar.getDriver();
			login = new login_demo(driver);
		}
			
		@WithTags({ @WithTag(type = "Logueo", name = "Logueo correcto"), @WithTag(type = "capability", name = "myCapabilityName") })
	    @Title("Prueba de loguearse")
	    @Test
	    public void Test_Loguearse() {
			login = new login_demo(driver);
			//System.out.println("Pasando el driver como argumento.");
			//login = (login) driver;
			System.out.println("Logueandose con credenciales...");
			login.loguearse("user@phptravels.com", "demouser"); 
			System.out.println("Chequeando URL: \n" + login.getCurrentUrl());
			assertTrue("PASS",login.getCurrentUrl()=="http://canalesdigitales.expand/frontEnd/panel");
	    } 
}
