package starter.math;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Title;
import net.thucydides.core.annotations.WithTag;
import net.thucydides.core.annotations.WithTags;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

@RunWith(SerenityRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class IPlugExcel {

    @Managed
    WebDriver jane;


    @WithTags({ @WithTag(type = "feature", name = "myFeatureName"), @WithTag(type = "capability", name = "myCapabilityName") })
    @Title("Do some testing here")
    @Test
    public void excel01_someTest() {
        jane.get("https://www.google.com.ua");
        WebElement busqueda = jane.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input")); 
        busqueda.sendKeys("algo");
        busqueda.sendKeys(Keys.ENTER);
        Assert.assertTrue(jane.getCurrentUrl().contains("www.google.com"));
    }
}
