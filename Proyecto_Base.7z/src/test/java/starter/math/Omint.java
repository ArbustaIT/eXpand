package starter.math;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.interactions.Actions;

public class Omint {
		
		private WebDriver driver;
		protected WebDriverWait wait;
		private static class time {
		public static void sleep (int time) throws InterruptedException {
			Thread.sleep(time*1000);
		}
		}
		
		@Before
		public void setUp() {
			System.setProperty("webdriver.chrome.driver", "C:\\automation\\driver\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
            options.addArguments("--incognito --ignore-certificate-errors");
            DesiredCapabilities capabilities = DesiredCapabilities.chrome();
            capabilities.setCapability(ChromeOptions.CAPABILITY, options);
            driver = new ChromeDriver(capabilities);
			driver.navigate().to("https://oaapp.eastus2.cloudapp.azure.com:8600/");		
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	        wait = new WebDriverWait(driver, 20);
	        //driver.get(URLBase);
	        driver.manage().window().maximize();
		}
		
		@Test
		public void testCartilla() throws InterruptedException {
			driver.findElement(By.xpath("//*[@id=\"dni\"]")).sendKeys("49709124");
			driver.findElement(By.xpath("//*[@id=\"user\"]")).sendKeys("prueba123");
			driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("p12345");
			
			driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/form/button")).click();
	        time.sleep(3);
	        WebElement btn_cartilla = driver.findElement(By.xpath("//*[@id=\"root\"]/div/header/div/div[1]/div[2]/a"));
	        btn_cartilla.click();
	        time.sleep(2);
	        WebElement btn_clinica = driver.findElement(By.xpath("/html/body/div[1]/div/main/div[1]/div/form/div[2]/div[1]/div/div[1]/div[1]"));
	        btn_clinica.click();
	        WebElement clinica_elegir = driver.findElement(By.xpath("html/body/div[1]/div/main/div[1]/div/form/div[2]/div[1]/div/div[2]/div/div[1]/div[2]/div/span"));
	        clinica_elegir.click();
	        time.sleep(1);
	        WebElement boton_donde = driver.findElement(By.xpath("//*[@id=\"locality\"]/div/div[1]"));
	        boton_donde.click();
	        WebElement boton_selec_donde = driver.findElement(By.xpath("/html/body/div[1]/div/main/div[1]/div/form/div[2]/div[2]/div/div[2]/div/div[1]/div[2]/div/span"));
	        boton_selec_donde.click();
	        time.sleep(2);
	        WebElement btn_buscar = driver.findElement(By.xpath("/html/body/div[1]/div/main/div[1]/div/form/div[3]/button[1]"));
	        btn_buscar.click();
	        time.sleep(2);
	        WebElement mapa = driver.findElement(By.xpath("/html/body/div[1]/div/main/div[2]/div[2]/div[1]/div[2]/a/img"));
	        mapa.click();
	        time.sleep(2);
	        
	        int index=0;
	        Set<String> windowHandles = driver.getWindowHandles();
	        List<String> windowStrings = new ArrayList<>(windowHandles);
	        String reqWindow = windowStrings.get(index);
	        
//	        windows_before = driver.window_handles[0];
//	        windows_after = driver.window_handles[1];
	        driver.switchTo().window(reqWindow);
//	        driver.switch_to_window(windows_after);
	        time.sleep(5);
//	        driver.switch_to_window(windows_before);
	        index=1;
	        driver.switchTo().window(reqWindow);
	        time.sleep(2);
	        WebElement btn_perfil = driver.findElement(By.xpath("//*[@id=\"root\"]/div/header/div/div[1]/div[4]"));
	        WebElement btn_salir = driver.findElement(By.xpath("/html/body/div/div/header/div/div[1]/div[4]/div/div[1]/button"));
	        //action = ActionChains(driver);
	        
	        //action.move_to_element(btn_perfil);
	        time.sleep(1);
	        //action.click(btn_salir);
	        //action.perform();
	        new Actions(driver).moveToElement(btn_perfil).click().perform();
		}
		
		
	
		@After
		public void tearDown() {
			driver.close();
			driver.quit();
		}
	}

